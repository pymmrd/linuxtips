package com.xxxx.manager.controller;

import com.xxxx.common.result.BaseResult;
import com.xxxx.common.result.FileResult;
import com.xxxx.manager.pojo.Brand;
import com.xxxx.manager.pojo.Goods;
import com.xxxx.manager.pojo.GoodsCategory;
import com.xxxx.manager.pojo.GoodsImages;
import com.xxxx.manager.service.BrandService;
import com.xxxx.manager.service.GoodsCategoryService;
import com.xxxx.manager.service.GoodsImagesService;
import com.xxxx.manager.service.GoodsService;
import com.xxxx.manager.service.UploadService;
import com.xxxx.manager.vo.GoodsCategoryVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 商品分类
 *
 * @author zhoubin
 * @since 1.0.0
 */
@Controller
@RequestMapping("goods")
public class GoodsController {

	@Autowired
	private GoodsCategoryService goodsCategoryService;
	@Autowired
	private BrandService brandService;
	@Autowired
	private GoodsService goodsService;
	@Autowired
	private GoodsImagesService goodsImagesService;
	@Autowired
	private UploadService uploadService;

	/**
	 * 跳转  商品分类-列表页
	 *
	 * @return
	 */
	@RequestMapping("category/list")
	public String categoryList(Model model) {
		List<GoodsCategoryVo> gcvList = goodsCategoryService.selectCategoryListForView();
		model.addAttribute("gcvList",gcvList);
		return "goods/category/category-list";
	}

	/**
	 * 跳转  商品分类-新增页
	 *
	 * @return
	 */
	@RequestMapping("category/add")
	public String categoryAdd(Model model) {
		List<GoodsCategory> gcList = goodsCategoryService.selectCategoryTopList();
		model.addAttribute("gcList", gcList);
		return "goods/category/category-add";
	}


	/**
	 * 商品分类-新增分类-级联查询
	 *
	 * @param parentId
	 * @return
	 */
	@RequestMapping("category/{parentId}")
	@ResponseBody
	public List<GoodsCategory> selectCategoryList(@PathVariable Short parentId) {
		return goodsCategoryService.selectCategoryByParentId(parentId);
	}


	/**
	 * 商品分类-新增分类-保存分类
	 * @param goodsCategory
	 * @return
	 */
	@RequestMapping("category/save")
	@ResponseBody
	public BaseResult categorySave(GoodsCategory goodsCategory) {
		int result = goodsCategoryService.categorySave(goodsCategory);
		return result > 0 ? BaseResult.success() : BaseResult.error();
	}

	/**
	 * 商品-列表-页面跳转
	 * @return
	 */
	@RequestMapping("list")
	public String goodsList(){
		return "goods/goods-list";
	}


	/**
	 * 商品-新增-页面跳转
	 * @return
	 */
	@RequestMapping("add")
	public String goodsAdd(Model model){
		//查询顶级分类
		List<GoodsCategory> gcList = goodsCategoryService.selectCategoryTopList();
		model.addAttribute("gcList",gcList);
		List<Brand> brandList = brandService.selectBrandList();
		model.addAttribute("brandList",brandList);
		return "goods/goods-add";
	}

	/**
	 * 商品新增-保存
	 * @param goods
	 * @return
	 */
	@RequestMapping("save")
	@ResponseBody
	public BaseResult saveGoods(Goods goods){
		return goodsService.saveGoods(goods);
	}


	/**
	 * 商品相册-保存
	 * @param file
	 * @param goodsId
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("images/save")
	@ResponseBody
	public BaseResult saveGoodsImages(MultipartFile file,Integer goodsId) throws IOException {
		String filename = file.getOriginalFilename();
		String date = DateTimeFormatter.ofPattern("yyyy/MM/dd/").format(LocalDateTime.now());
		filename = date+System.currentTimeMillis()+filename.substring(filename.lastIndexOf("."));
		FileResult result = uploadService.upload(file.getInputStream(), filename);
		//上传成功
		if (!StringUtils.isEmpty(result.getFileUrl())){
			GoodsImages goodsImages = new GoodsImages();
			goodsImages.setImageUrl(result.getFileUrl());
			goodsImages.setGoodsId(goodsId);
			BaseResult baseResult = goodsImagesService.saveGoodsImages(goodsImages);
			return baseResult;
		}else {
			return BaseResult.error();
		}
	}
}
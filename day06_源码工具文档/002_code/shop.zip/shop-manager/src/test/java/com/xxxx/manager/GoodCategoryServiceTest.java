package com.xxxx.manager;

import com.xxxx.manager.service.GoodsCategoryService;
import com.xxxx.manager.vo.GoodsCategoryVo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.util.HtmlUtils;

import java.util.List;

/**
 * 商品分类服务测试类
 *
 * @author zhoubin
 * @since 1.0.0
 */
@SpringBootTest
public class GoodCategoryServiceTest {
	@Autowired
	private GoodsCategoryService goodsCategoryService;

	@Test
	public void testSelectCategoryListForView(){
		List<GoodsCategoryVo> gcvList = goodsCategoryService.selectCategoryListForView();
		System.out.println(gcvList);
	}


	@Test
	public void testHtml(){
		String html = HtmlUtils.htmlEscape("<p>测试html文本转义</p>", "UTF-8");
		System.out.println(html);
		System.out.println(HtmlUtils.htmlUnescape(html));
	}
}
package com.xxxx.uploaddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadDemoApplication.class, args);
	}

}

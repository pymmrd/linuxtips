package com.xxxx.uploaddemo.service;

import java.io.InputStream;

/**
 * 上传服务
 */
public interface UploadService {
	/**
	 * 上传服务
	 * @param inputStream
	 * @param fileName
	 * @return
	 */
	String upload(InputStream inputStream,String fileName);
}

package com.xxxx.manager.service;

import com.xxxx.manager.pojo.Brand;

import java.util.List;

/**
 * 品牌service
 */
public interface BrandService {
	/**
	 * 查询所有品牌
	 * @return
	 */
	List<Brand> selectBrandList();
}

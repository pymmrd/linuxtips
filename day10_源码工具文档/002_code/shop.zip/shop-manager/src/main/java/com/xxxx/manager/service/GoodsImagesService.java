package com.xxxx.manager.service;

import com.xxxx.common.result.BaseResult;
import com.xxxx.manager.pojo.GoodsImages;

/**
 * 商品相册服务
 */
public interface GoodsImagesService {
	/**
	 * 商品相册保存
	 * @param goodsImages
	 * @return
	 */
	BaseResult saveGoodsImages(GoodsImages goodsImages);
}

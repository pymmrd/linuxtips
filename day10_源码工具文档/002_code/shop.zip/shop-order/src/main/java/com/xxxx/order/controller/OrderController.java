package com.xxxx.order.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.xxxx.common.pojo.Admin;
import com.xxxx.common.result.BaseResult;
import com.xxxx.order.service.OrderService;
import com.xxxx.rpc.service.CartService;
import com.xxxx.rpc.vo.CartResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * 订单Controller
 *
 * @author zhoubin
 * @since 1.0.0
 */
@Controller
@RequestMapping("order")
public class OrderController {

	@Reference(interfaceClass = CartService.class)
	private CartService cartService;
	@Autowired
	private OrderService orderService;

	/**
	 * 跳转到预订单页面
	 * @return
	 */
	@RequestMapping("preOrder")
	public String preOrder(Model model, HttpServletRequest request){
		Admin admin = (Admin) request.getSession().getAttribute("user");
		model.addAttribute("cartResult",cartService.getCartList(admin));
		return "order/preOrder";
	}

	/**
	 * 跳转到订单提交页面
	 * @return
	 */
	@RequestMapping("submitOrder")
	public String submitOrder(Model model,HttpServletRequest request){
		Admin admin = (Admin) request.getSession().getAttribute("user");
		CartResult cartResult = cartService.getCartList(admin);
		//1.存入订单信息
		BaseResult baseResult = orderService.orderSave(admin, cartResult);
		//2.清除购物车信息
		cartService.clearCart(admin);
		//总价
		model.addAttribute("totalPrice",cartResult.getTotalPrice());
		//订单编号
		model.addAttribute("orderSn",baseResult.getMessage());
		//3.页面跳转
		return "order/submitOrder";
	}

}
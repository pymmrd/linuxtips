package com.xxxx.order;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;

/**
 * Redis测试类
 *
 * @author zhoubin
 * @since 1.0.0
 */
@SpringBootTest
public class RedisTest {

	@Autowired
	private RedisTemplate<String,String> redisTemplate;


	@Test
	public void testGetIncrement(){
		RedisAtomicLong entityIdCounter = new RedisAtomicLong("order:increment",redisTemplate.getConnectionFactory());
		long increment = entityIdCounter.getAndIncrement();
		System.out.println(increment);
	}

}
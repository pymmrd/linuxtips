package com.xxxx.portal.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.xxxx.rpc.service.GoodsCategoryService;
import com.xxxx.rpc.vo.GoodsCategoryVo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 商品controller
 *
 * @author zhoubin
 * @since 1.0.0
 */
@Controller
@RequestMapping("goodsCategory")
public class GoodsController {

	@Reference(interfaceClass = GoodsCategoryService.class)
	private GoodsCategoryService goodsCategoryService;


	/**
	 * 查询商品分类列表
	 * @return
	 */
	@RequestMapping("list")
	@ResponseBody
	public List<GoodsCategoryVo> categoryList(){
		return goodsCategoryService.selectCategoryListForView();
	}
}